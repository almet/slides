# Retours :)

.fx: title

---

## C'est qui ce mec ?

.fx: bigbullet

* Ancien élève de la baro (promo 2008)
* Parcours un peu "atypique"
* Developeur python (bibliothèques de packaging)
* chez Mozilla depuis fin 2011 (services)

---

## Mozilla

.fx: bigbullet

* Une association à but non lucratif
* Faire en sorte que le web reste un lieu libre et ouvert
* Protection de la vie privée
* B2G, BrowserID…
* travaille principalement sur le coté services web

---

## Qu'est-ce que je fais là ?

.fx: bigbullet

* Retour d'experience sur les années que j'ai passées à étudier
* Parlons de logiciel libre
* Quelques opportunitées qui peuvent être interessantes pour des stages

---

## Parcours

.fx: bigbullet

* 2 premières années de fac avec le BTS (Maths, Informatique)
* 2 années de BTS IRIS
* 2 années à SUPINFO (Toulouse)
* 1 année à Oxford Brookes University (UK)

---

# SUPINFO

.fx: title

---

## les bons cotés

.fx: bigbullet

* Des écoles un peu partout en france, et quelques unes à l'étranger
* Des partenariats avec certaines facultées (Dominican University à SF, Brookes
  à Oxford)
* Une formation en alternance (2 jours par semaine en entreprise)

---

## … et les moins bons

.fx: bigbullet

* Très orienté "technologies" (Microsoft, Oracle, Apple)
* Une école privée (~5000€ par an)
* Des soucis d'organisation (changements de locaux, difficile d'avoir des
  réponses de la part de l'administration…)

---

# Oxford Brookes

.fx: title

---

## Oxford Brookes

.fx: bigbullet

* À l'étranger
* De la théorie
* Reconaissance
* Du challenge !


---

## des mauvais cotés ?

.fx: bigbullet

* trop de théorie ?
* académique

---

# Logiciel libre

.fx: title

---

## Google Summer of Code (GSoC)

.fx: bigbullet

* un programme de google pour favoriser les contributeurs
* Mentoré (par des contributeurs au projet)
* Payé (et plutôt bien payé)
* Effet wow™

---

## Mozilla, Python, Linux…

.fx: bigbullet

* travailler sur des projets utiles
* Apprendre comment ça fonctionne "de l'intérieur"
* possibilité de s'investir dans la communauté


---

# En vrac

.fx: title

---

## Conseils

.fx: bigbullet

* investissez vous dans des projets libres
* utilisez github, contribuez à des petits projets
* allez aux conférences, soyez curieux !
* faites ! écrivez du code, bidouillez


---

# Questions ?

.fx: title

---

## Merci

.fx: bigbullet

* http://notmyidea.org
* alexis@notmyidea.org
* alexis@mozilla.com
