# A context-aware web recommendation system 

.fx: title

---

## The problematic

.fx: bigbullet

* Making **recommendations**
* For the **web**
* Using the **browsing context**
* Web recommender exists but none is using contextual information

---

## Motivations

.fx: bigbullet

* Discovering the machine learning field
* A *simple* idea that have no existing implementation
* Comparing existing algorithms and techniques
