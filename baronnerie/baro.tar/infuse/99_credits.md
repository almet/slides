# Questions ?

.fx: title

---

## Research

Here are the main papers on the subject (but there is tons of them that are interesting and useful)
*  Adomavicius, G., & Tuzhilin, a. (2005). **Toward the next generation of recommender systems: a survey of the state-of-the-art and possible extensions**. IEEE Transactions on Knowledge and Data Engineering
* Balabanović, M., & Shoham, Y. (1997). **Fab: content-based, collaborative recommendation**. Communications of the ACM, 
* Dubroy, P., & Balakrishnan, R. (2010). **A study of tabbed browsing among mozilla firefox users**. Proceedings of the 28th international conference on Human factors in computing systems 
 * Kohlschutter, C., Fankhauser, P., & Nejdl, W. (2010). **Boilerplate detection using shallow text features**. Proceedings of the third ACM international conference on Web search and data mining 
* Melville, P., Mooney, R. J., & Nagarajan, R. (2002). **Content-Boosted Collaborative Filtering for Improved Recommendations**. Machine Learning, 
